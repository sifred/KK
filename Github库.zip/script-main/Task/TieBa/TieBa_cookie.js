# 百度贴吧每日自动签到获取Cookie
^https?:\/\/(c\.tieba\.baidu\.com|180\.97\.\d+\.\d+)\/c\/s\/login url script-request-header https://raw.githubusercontent.com/chxm1023/script/main/Task/TieBa/TieBa_signin.js
^https?:\/\/c\.tieba\.baidu\.com\/c\/s\/channelIconConfig url script-request-header https://raw.githubusercontent.com/chxm1023/script/main/Task/TieBa/TieBa_signin.js
^https?:\/\/tiebac\.baidu\.com\/c\/u\/follow\/getFoldedMessageUserInfo url script-request-header https://raw.githubusercontent.com/chxm1023/script/main/Task/TieBa/TieBa_signin.js

hostname= c.tieba.baidu.com
