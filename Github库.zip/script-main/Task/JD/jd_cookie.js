# 京东Cookie 登录网址：https://bean.m.jd.com/bean/signIndex.action
^https:\/\/(api\.m|me-api)\.jd\.com\/(client\.action\?functionId=signBean|user_new\/info\/GetJDUserInfoUnion\?) url script-request-header https://raw.githubusercontent.com/chxm1023/script/main/Task/JD/JD_DailyBonus.js

hostname = ms.jr.jd.com, me-api.jd.com, api.m.jd.com
